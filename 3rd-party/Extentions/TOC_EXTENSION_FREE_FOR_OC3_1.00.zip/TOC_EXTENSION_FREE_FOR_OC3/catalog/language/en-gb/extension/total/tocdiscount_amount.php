<?php
$_['text_discount_amount'] = 'ส่วนลดตามยอดสั่งซื้อ';
?>