<?php
// Text
$_['text_title']       = '';
$_['text_description'] = '&nbsp;จัดส่ง  Kerry Express(ตามน้ำหนัก)';
?>