<?php
// Text
$_['text_title']       = '';
$_['text_description'] = '&nbsp;จัดส่ง(ตามจ.น.ชิ้น)';
?>