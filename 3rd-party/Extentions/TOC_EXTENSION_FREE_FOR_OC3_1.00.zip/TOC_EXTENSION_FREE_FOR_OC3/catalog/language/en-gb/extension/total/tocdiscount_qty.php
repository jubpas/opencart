<?php
$_['text_discount_qty'] = 'ส่วนลดตามจำนวนชิ้น';
?>