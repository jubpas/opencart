<?php
// Text
$_['text_title']       = '';
$_['text_description'] = '&nbsp;จัดส่ง EMS(ตามจ.น.ชิ้น)';
?>