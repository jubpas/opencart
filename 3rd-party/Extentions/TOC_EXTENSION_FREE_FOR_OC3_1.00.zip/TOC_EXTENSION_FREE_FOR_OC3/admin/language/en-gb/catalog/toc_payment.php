<?php
// Text
$_['heading_title'] = 'รายงานการแจ้งโอนเงิน'; 
$_['text_date_added']  = 'วันแจ้ง';
$_['text_date_transfer']  = 'วันโอน';
$_['text_name']  = 'ชื่อ';
$_['text_tel']  = 'เบอร์โทร';
$_['text_orderno']  = 'เลขที่สั่งซื้อ';
$_['text_amount']  = 'ยอดโอน';
$_['text_comment']  = 'คอมเมนต์';
$_['text_slip']  = 'สลิป';
$_['text_email']  = 'อีเมล์';
$_['text_bank']  = 'โอนเข้าธนาคาร';