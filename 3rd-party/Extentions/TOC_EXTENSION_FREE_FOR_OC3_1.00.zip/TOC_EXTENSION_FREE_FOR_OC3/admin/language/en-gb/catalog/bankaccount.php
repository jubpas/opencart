<?php
$_['heading_title_bank_list']= 'เพิ่มบัญชีธนาคาร สำหรับลูกค้าแจ้งชำระเงิน'; 
$_['heading_title_bank']   = 'บัญชีธนาคาร';
//text menu          
$_['text_bank_module']    = 'บัญชีธนาคาร';                  
$_['text_shipping_module']    = 'การจัดส่ง';                                                              
$_['text_tocshipping']    = 'ค่าจัดส่ง';                                                                    
$_['text_discount']    = 'ส่วนลด';    
$_['text_addbank']= 'เพิ่มบัญชีธนาคาร' ;
$_['column_bank_account']= 'บัญชีธนาคาร';
$_['column_sort_order']= 'ลำดับที่';
$_['column_action']= 'แก้ไข';

$_['text_toctotal']= 'คำนวณยอดเงินรวม';
$_['text_tocpayment']= 'ช่องทางชำระเงิน';
$_['text_payment_notice']= 'ลูกค้าแจ้งชำระเงิน';
 $_['text_success']= 'สถานะแก้ไขเสร็จสมบูรณ์';
// Entry 
$_['entry_status']        = 'สถานะ:';
$_['entry_sort_order']    = 'การจัดเรียงลำดับ:'; 
$_['entry_link']    = 'ลิงค์';
$_['entry_image']    = 'รูปภาพ';
$_['entry_information']    = 'กรอกข้อมูล';
$_['entry_bankinfo'] = 'ข้อมูลบัญชี';
$_['entry_bankname'] = 'ธนาคาร';
$_['entry_accname'] = 'ชื่อบัญชี';
$_['entry_bankno'] = 'หมายเลขบัญชี';  