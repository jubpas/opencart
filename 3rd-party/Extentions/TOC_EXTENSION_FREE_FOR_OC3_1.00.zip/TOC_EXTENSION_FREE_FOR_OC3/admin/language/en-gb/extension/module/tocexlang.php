<?php

//text menu          
$_['text_bank_module']    = 'บัญชีธนาคาร';                  
$_['text_shipping_module']    = 'การจัดส่ง';                                                              
$_['text_tocshipping']    = 'ค่าจัดส่ง';                                                                    
$_['text_discount']    = 'ส่วนลด';    
$_['text_addbank']= 'เพิ่มบัญชีธนาคาร' ;
$_['text_toctotal']= 'คำนวณยอดเงินรวม';
$_['text_tocskin']= 'Skin ตั้งต้น 10 แบบ';
$_['text_tocpayment']= 'ช่องทางชำระเงิน';
$_['text_payment_notice']= 'ลูกค้าแจ้งชำระเงิน';