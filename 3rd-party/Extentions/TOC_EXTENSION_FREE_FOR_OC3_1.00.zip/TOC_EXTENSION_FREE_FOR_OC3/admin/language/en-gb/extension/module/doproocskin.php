<?php
// Heading
$_['heading_title']    = 'Dopro OC Skin By TemplateOpencart.net';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified module opencart default skin!';
$_['text_edit']        = 'Edit Status';
$_['entry_status']     = 'Status';
$_['column_action']     = 'Action';
$_['text_name']     = 'Name';
$_['text_list']     = 'List of skin';
$_['text_status']     = 'Status';
$_['text_image']     = 'Image';
// Error
$_['error_permission'] = 'Warning: You do not have permission to modify this module!';
 