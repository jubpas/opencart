<?php
// Heading
$_['heading_title']    = 'Thai translate database';

// Text
$_['text_module']      = 'โมดูล';
$_['text_success']     = 'สถานะ: แก้ไขข้อมูลเสร็จสมบูรณ์!';
$_['text_update']        = 'ปรับปรุงฐานข้อมูลภาษาไทย';

 
// Error
$_['error_permission'] = 'Warning: You do not have permission to modify bestsellers module!';
$_['error_name']       = 'Module Name must be between 3 and 64 characters!';
$_['error_width']      = 'Width required!';
$_['error_height']     = 'Height required!';