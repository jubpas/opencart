<?php
// Heading
$_['heading_title']     = 'สร้างเนื้อหา HTML';
// Text
$_['text_module']      = 'โมดูล';
$_['text_success']     = 'สถานะ: แก้ไขข้อมูลเสร็จสมบูรณ์!';
$_['text_edit']        = 'แก้ไขโมดูล  ';
$_['text_extension']   = 'ส่วนเสริม'; 
// Entry
$_['entry_name']       = 'ตั้งชื่อโมดูล';
$_['entry_title']       = 'หัวข้อ';
$_['entry_description'] = 'รายละเอียด';
$_['entry_status']     = 'สถานะ';

// Error
$_['error_permission']  = 'Warning: You do not have permission to modify HTML Content module!';
$_['error_name']        = 'Module Name must be between 3 and 64 characters!';