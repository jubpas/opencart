<?php
// Heading
$_['heading_title']    = 'ฟรีค่าจัดส่ง';

// Text
$_['text_shipping']    = 'ค่าจัดส่ง';
$_['text_success']     = 'สถานะการแก้ไขเสร็จสมบูรณ์!';
$_['text_edit']        = 'แก้ไขข้อมูล';
$_['text_extension']   = 'ค่าจัดส่ง';
// Entry
$_['entry_total']      = 'ยอดรวม';
$_['entry_geo_zone']   = 'Geo Zone';
$_['entry_status']		 = 'สถานะ';
$_['entry_sort_order']	 = 'เรียงลำดับ';

// Help
$_['help_total']       = 'Sub-Total amount needed before the free shipping module becomes available.';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify free shipping!';