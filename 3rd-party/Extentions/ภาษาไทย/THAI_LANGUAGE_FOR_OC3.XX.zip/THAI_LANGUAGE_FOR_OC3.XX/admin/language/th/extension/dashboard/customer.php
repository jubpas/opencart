<?php
// Heading
$_['heading_title'] = 'ลูกค้าทั้งหมด';

// Text
$_['text_view'] = 'ดูรายละเอียดเพิ่มเติม...';