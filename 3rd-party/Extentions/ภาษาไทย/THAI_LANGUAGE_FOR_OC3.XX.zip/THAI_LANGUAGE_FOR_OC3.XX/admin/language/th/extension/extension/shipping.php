<?php
// Heading
$_['heading_title']     = 'ค่าจัดส่ง';

// Text
$_['text_success']      = 'เสร็จสมบูรณ์: แก้ไขข้อมูลเรียบร้อยแล้ว!';
$_['text_list']         = 'รายการค่าจัดส่ง';

// Column
$_['column_name']       = 'ประเภทค่าจัดส่ง';
$_['column_status']     = 'สถานะ';
$_['column_sort_order'] = 'เรียงลำดับ';
$_['column_action']     = 'แก้ไข';

// Error
$_['error_permission']  = 'Warning: You do not have permission to modify shipping!';