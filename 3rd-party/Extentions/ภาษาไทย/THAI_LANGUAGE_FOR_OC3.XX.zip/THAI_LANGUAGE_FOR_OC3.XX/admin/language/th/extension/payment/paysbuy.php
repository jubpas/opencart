<?php
// Heading
$_['heading_title']      = 'Paysbuy';

// Text 
$_['text_payment']       = 'Payment';
$_['text_success']       = 'Success: You have modified Paysbuy account details!';
$_['text_paysbuy']   = '<a onclick="window.open(\'https://www.paysbuy.com/\');">
<img src="view/image/payment/paysbuy.gif" alt="Paysby" title="Paysby" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_authorization'] = 'System Test';
$_['text_sale']          = 'Payment';

// Entry
$_['entry_email']        = 'E-Mail:';
$_['entry_transaction']  = 'Transaction Method:';
$_['entry_total']		 = 'ยอดรวม';
$_['entry_order_status'] = 'ปรับสถานะออเดอร์เป็น';
$_['entry_geo_zone']	 = 'Geo Zone';
$_['entry_status']		 = 'สถานะ';
$_['entry_sort_order']	 = 'เรียงลำดับ';


$_['text_pay_comp']	     = 'Complete for pay ment';
$_['text_updatestatus_callback']= 'Callback to Frontend';
$_['text_updatestatus_callbackground_process']= 'Call from Background Process';
$_['entry_updatestatus'] = 'Update Status Payment';
// Error
$_['error_permission']   = 'Warning: You do not have permission to modify payment Paysbuy!';
$_['error_email']        = 'E-Mail required!'; 
?>