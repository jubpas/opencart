<?php
// Heading
$_['heading_title']         = 'รายงานการใช้เครดิต';

// Column
$_['text_list']             = 'รายงานการใช้เครดิต';
$_['column_customer']       = 'ชื่อลูกค้า';
$_['column_email']          = 'อีเมล์';
$_['column_customer_group'] = 'กลุ่มลูกค้า';
$_['column_status']         = 'สถานะ';
$_['column_total']          = 'ยอดเงิน';
$_['column_action']         = 'ดำเนินการ';
// Entry
$_['entry_date_start']      = 'วันเริ่มต้น';
$_['entry_date_end']        = 'จนถึง';


$_['column_customer']       = 'ชื่อลูกค้า';
$_['column_email']          = 'อีมเล์';
$_['column_customer_group'] = 'กลุ่มลูกค้า';
$_['column_status']         = 'สถานะ';
$_['column_points']         = 'คะแนนสะสม';
$_['column_orders']         = 'หมายเลขคำสั่งซื้อ';
$_['column_total']          = 'ยอดเงิน';
$_['column_action']         = 'ดำเนินการ';