<?php
// Heading
$_['heading_title']    = 'รายงานคูปองส่วนลด';

// Text
$_['text_list']        = 'รายงานการใช้คูปอง';

// Column
$_['column_name']      = 'ชื่อคูปอง';
$_['column_code']      = 'รหัส';
$_['column_orders']    = 'คำสั่งซื้อ';
$_['column_total']     = 'ยอดเงิน';
$_['column_action']    = 'ดำเนินการ';

// Entry
$_['entry_date_start']   = 'วันเริ่มต้น';
$_['entry_date_end']    = 'จนถึง';