<?php
// Heading
$_['heading_title']     = 'คำสั่งซื้อล่าสุด';

// Column
$_['column_order_id']   = 'หมายเลขคำสั่งซื้อ';
$_['column_customer']   = 'ลูกค้า';
$_['column_status']     = 'สถานะ';
$_['column_total']      = 'ยอดรวม';
$_['column_date_added'] = 'วันที่';
$_['column_action']     = 'ดู';