<?php
// header
$_['heading_title']  = 'บริหารจัดการระบบ Opencart';

// Text
$_['text_heading']   = 'ผู้ดูแลระบบ';
$_['text_login']     = 'ล็อคอิน';
$_['text_forgotten'] = 'ลืมรหัสผ่าน';

// Entry
$_['entry_username'] = 'บัญชีผู้ใช้';
$_['entry_password'] = 'รหัสผ่าน';

// Button
$_['button_login']   = 'ล็อคอิน';

// Error
$_['error_login']    = 'No match for Username and/or Password.';
$_['error_token']    = 'Invalid token session. Please login again.';