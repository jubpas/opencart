<?php
// Heading
$_['heading_title'] = 'ออนไลน์ขณะนี้';

// Text
$_['text_view']     = 'ดูเพิ่มเติม...';