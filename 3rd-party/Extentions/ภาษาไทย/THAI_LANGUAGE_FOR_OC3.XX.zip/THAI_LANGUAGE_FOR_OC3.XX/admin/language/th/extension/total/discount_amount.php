<?php
// Heading
$_['heading_title']    = 'ส่วนลด(%)ตามยอดสั่งซื้อ';

// Text
$_['text_total']       = 'ยอดเงินรวม';
$_['text_success']     = 'สถานะ:การแก้ไขเสร็จสมบูรณ์!';
$_['text_percent_discount']    = 'ยอดสั่งซื้อ : ส่วนลด (%):<br /> ตัวอย่าง: 500:0, 1000:5,999999:10 <br/>หมายถึง <br /> ยอดสั่งซื้่อตั้งแต่ 0-500 บาท ได้ส่วนลด 0%  <br />ตั้งแต่ 500-1000 บาท ได้ส่วนลด 5%  <br />ตั้งแต่่ 1000 บาทขึ้นไป ได้ส่วนลด 10%  </span>'; 
// Entry
$_['entry_status']     = 'สถานะ:';
$_['entry_sort_order'] = 'การจัดเรียงลำดับ:';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify coupon total!';
?>