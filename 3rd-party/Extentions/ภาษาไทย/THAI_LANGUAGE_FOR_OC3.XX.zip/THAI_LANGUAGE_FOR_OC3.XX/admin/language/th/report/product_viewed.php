<?php
// Heading
$_['heading_title']    = 'รายงานการเข้าชมสินค้า';

// Text
$_['text_list']        = 'รายการสินค้าที่มีการเข้าชม';
$_['text_success']     = 'Success: You have reset the product viewed report!';

// Column
$_['column_name']      = 'รายละเอียดสินค้า';
$_['column_model']     = 'รหัส';
$_['column_viewed']    = 'จำนวนผู้เข้าชม';
$_['column_percent']   = 'เปอร์เซ็น';

// Error
$_['error_permission'] = 'Warning: You do not have permission to reset product viewed report!';