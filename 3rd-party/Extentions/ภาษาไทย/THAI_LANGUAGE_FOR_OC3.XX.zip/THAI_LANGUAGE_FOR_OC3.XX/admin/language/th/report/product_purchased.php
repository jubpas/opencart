<?php
// Heading
$_['heading_title']     = 'รายงานสินค้าที่มีการสั่งซื้อมากที่สุด';

// Text
$_['text_list']         = 'แสดงรายการสินค้าที่มีการสั่งซื้อมากที่สุด';
$_['text_all_status']   = 'ทุกสถานะ';

// Column
$_['column_date_start']  = 'วันเริ่มต้น';
$_['column_date_end']   = 'จนถึง';
$_['column_name']       = 'ชื่อสินค้า';
$_['column_model']      = 'รหัส';
$_['column_quantity']   = 'จำนวน';
$_['column_total']      = 'ยอดเงิน';

// Entry
$_['entry_date_start']   = 'วันเริ่มต้น';
$_['entry_date_end']    = 'จนถึง';
$_['entry_status']      = 'สถานะคำสั่งซื้อ'; 