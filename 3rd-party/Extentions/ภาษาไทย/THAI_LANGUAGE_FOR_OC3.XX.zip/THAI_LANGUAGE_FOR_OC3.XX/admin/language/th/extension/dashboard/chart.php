<?php
// Heading
$_['heading_title'] = 'วิเคราะห์การขาย';

// Text
$_['text_order']    = 'คำสั่งซื้อ';
$_['text_customer'] = 'ลูกค้า';
$_['text_day']      = 'วันนี้';
$_['text_week']     = 'สัปดาห์นี้';
$_['text_month']    = 'เดือนที่ผ่านมา';
$_['text_year']     = 'ปีที่ผ่านมา';