<?php
// Heading
$_['heading_title']    = 'บัญชีผู้ใช้';

$_['text_module']      = 'โมดูล';
$_['text_success']        = 'สถานะ: แก้ไขข้อมูลเสร็จสมบูรณ์!';
$_['text_edit']        = 'แก้ไขโมดูล บัญชีผู้ใช้';
$_['text_extension']   = 'ส่วนเสริม'; 
// Entry
$_['entry_status']        = 'สถานะ:';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify account module!';