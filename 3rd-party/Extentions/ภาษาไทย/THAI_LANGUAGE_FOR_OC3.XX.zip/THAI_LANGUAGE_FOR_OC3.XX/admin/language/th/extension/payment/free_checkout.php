<?php
// Heading
$_['heading_title']		 = 'ฟรี(ค่าสินค้าและบริการ)';

// Text
$_['text_payment']		 = 'การชำระเงิน';
$_['text_success']		 = 'สถานะเสร็จสมบูรณ์!';
$_['text_edit']          = 'แก้ไขข้อมุล';

// Entry
$_['entry_order_status'] = 'ปรับสถานะออเดอร์เป็น';
$_['entry_status']		 = 'สถานะ';
$_['entry_sort_order']	 = 'เรียงลำดับ';

// Error
$_['error_permission']	  = 'Warning: You do not have permission to modify payment Free Checkout!';