<?php
// Heading
$_['heading_title']     = 'รายงานผู้เยี่ยมชมเว็บไซต์';

// Text
$_['text_list']         = 'รายชื่อผู้เยี่ยมชมเว็บไซต์';
$_['text_guest']        = 'ผู้เยี่ยมชม';

// Column
$_['column_ip']         = 'ไอพีแอดเดรส';
$_['column_customer']   = 'ลูกค้า';
$_['column_url']        = 'หน้าที่เยี่ยมชมล่าสุด';
$_['column_referer']    = 'มาจาก';
$_['column_date_added'] = 'คลิกล่าสุด';
$_['column_action']     = 'ดำเนินการ';

// Entry
$_['entry_ip']          = 'ไอพีแอดเดรส';
$_['entry_customer']   = 'ลูกค้า'; 