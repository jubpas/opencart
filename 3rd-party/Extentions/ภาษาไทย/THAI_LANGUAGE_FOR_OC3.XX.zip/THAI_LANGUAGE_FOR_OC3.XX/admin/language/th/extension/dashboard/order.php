<?php
// Heading
$_['heading_title'] = 'คำสั่งซื้อทั้งหมด';

// Text
$_['text_view']     = 'ดูเพิ่มเติม...';