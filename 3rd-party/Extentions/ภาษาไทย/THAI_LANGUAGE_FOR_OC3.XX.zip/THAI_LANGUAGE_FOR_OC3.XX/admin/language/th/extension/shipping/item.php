<?php
// Heading
$_['heading_title']     = 'ค่าจัดส่งต่อสินค้า 1 รายการ';

// Text
$_['text_shipping']    = 'ค่าจัดส่งต่อสินค้า  1 รายการ';
$_['text_success']     = 'สถานะการแก้ไขเสร็จสมบูรณ์!';
$_['text_edit']        = 'แก้ไขข้อมูล';
$_['text_extension']   = 'ค่าจัดส่ง';

// Entry
$_['entry_cost']       = 'ค่าจัดส่ง';
$_['entry_tax_class']  = 'Tax Class';
$_['entry_geo_zone']   = 'Geo Zone';
$_['entry_status']		 = 'สถานะ';
$_['entry_sort_order']	 = 'เรียงลำดับ';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify shipping per item rates!';