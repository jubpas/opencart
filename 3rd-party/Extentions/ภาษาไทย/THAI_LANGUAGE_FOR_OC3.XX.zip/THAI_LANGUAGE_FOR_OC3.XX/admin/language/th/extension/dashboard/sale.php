<?php
// Heading
$_['heading_title'] = 'ยอดขายทั้งหมด';

// Text
$_['text_view']     = 'ดูเพิ่มเติม...';