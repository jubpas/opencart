<?php
// Heading
$_['heading_title']    = 'Quantity Based Shipping';