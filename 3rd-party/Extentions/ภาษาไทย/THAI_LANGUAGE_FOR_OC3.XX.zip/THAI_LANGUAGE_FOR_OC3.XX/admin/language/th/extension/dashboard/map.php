<?php
// Heading
$_['heading_title'] = 'ประเทศที่สั่งซื้อ';

$_['text_order']    = 'คำสั่งซื้อ';
$_['text_sale']     = 'ยอดขาย';