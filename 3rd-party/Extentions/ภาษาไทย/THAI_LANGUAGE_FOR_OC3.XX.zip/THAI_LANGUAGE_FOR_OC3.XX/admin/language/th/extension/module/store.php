<?php
// Heading
$_['heading_title']    = 'ข้อมูลร้านค้า';

// Text
$_['text_module']      = 'โมดูล';
$_['text_success']     = 'สถานะ: แก้ไขข้อมูลเสร็จสมบูรณ์!';
$_['text_edit']        = 'แก้ไขโมดูล  ';
$_['text_extension']   = 'ส่วนเสริม'; 
// Entry
$_['entry_admin']      = 'โชว์เฉพาะผู้ดูแลระบบ';
$_['entry_status']     = 'สถานะ';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify store module!';