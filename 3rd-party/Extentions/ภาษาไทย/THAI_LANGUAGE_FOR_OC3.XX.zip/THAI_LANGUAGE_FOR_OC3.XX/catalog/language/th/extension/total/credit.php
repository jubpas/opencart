<?php
$_['text_credit']   = 'เครดิต';
$_['text_order_id'] = 'หมายเลขคำสั่งซื้อ: #%s';