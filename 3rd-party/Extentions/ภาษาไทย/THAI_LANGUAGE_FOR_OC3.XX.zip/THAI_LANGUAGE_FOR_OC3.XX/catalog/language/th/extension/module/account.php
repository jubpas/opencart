<?php
// Heading
$_['heading_title']    = 'บัญชีผู้ใช้';

// Text
$_['text_register']    = 'ลงทะเบียน';
$_['text_login']       = 'ล็อคอิน';
$_['text_logout']      = 'ออกจากระบบ';
$_['text_forgotten']   = 'ลืมรหัสผ่าน';
$_['text_account']     = 'บัญชีผู้ใช้';
$_['text_edit']        = 'แก้ไขข้อมูล';
$_['text_password']    = 'รหัสผ่าน';
$_['text_address']     = 'ที่อยู่';
$_['text_wishlist']    = 'รายการโปรด';
$_['text_order']       = 'ประวัติการสั่งซื้อ';
$_['text_download']    = 'ดาวน์โหลด';
$_['text_reward']      = 'คะแนนสะสม';
$_['text_return']      = 'การคืนสินค้า';
$_['text_transaction'] = 'รายการข้อมูล';
$_['text_newsletter']  = 'ข่าวสารร้านค้า';
$_['text_recurring']   = 'การผ่อนชำระ';