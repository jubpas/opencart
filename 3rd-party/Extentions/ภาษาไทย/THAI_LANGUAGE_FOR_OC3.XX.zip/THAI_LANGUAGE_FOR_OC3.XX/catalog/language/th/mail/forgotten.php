<?php
// Text
$_['text_subject']  = '%s - รหัสผ่านใหม่';
$_['text_greeting'] = 'รหัสผ่านใหม่ถูกร้องขอจาก %s.';
$_['text_password'] = 'รหัสผ่านใหม่ของคุณคือ:';