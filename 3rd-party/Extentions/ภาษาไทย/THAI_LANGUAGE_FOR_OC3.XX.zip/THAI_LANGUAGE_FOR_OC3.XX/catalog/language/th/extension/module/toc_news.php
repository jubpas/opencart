<?php
// Heading
$_['heading_titlenews'] = 'หมวดหมู่ ข่าวสารกิจกรรม';
$_['text_article_pick'] = 'บทความเด่น';
?>