<?php
// Text
$_['heading_title']  ='ช้อปตามหมวดหมู่';
$_['text_viewall']   = 'ดูทั้งหมด';
 
?>