<?php
// Text
$_['text_home']          = 'หน้าแรก';
$_['text_wishlist']      = 'รายการโปรด (%s)';
$_['text_shopping_cart'] = 'ตระกร้าสินค้า';
$_['text_category']      = 'หมวดหมู่สินค้า';
$_['text_menu']           = 'เมนู';
$_['text_account']       = 'บัญชีผู้ใช้';
$_['text_register']      = 'ลงทะเบียน';
$_['text_login']         = 'เข้าสู่ระบบ';
$_['text_order']         = 'ประวัติการสั่งซื้อ';
$_['text_transaction']   = 'ธรุกรรมการเงิน';
$_['text_download']      = 'ดาวน์โหลด';
$_['text_logout']        = 'ออกจากระบบ';
$_['text_checkout']      = 'สั่งซื้อ';
$_['text_search']        = 'ค้นหา';
$_['text_all']           = 'แสดงทั้งหมด';