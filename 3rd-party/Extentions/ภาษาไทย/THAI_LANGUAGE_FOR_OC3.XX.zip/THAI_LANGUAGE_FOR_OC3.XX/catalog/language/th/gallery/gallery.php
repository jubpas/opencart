<?php
// Text
$_['text_gallery']    = 'แกลลอรี่';
$_['text_heading']     = 'แกลลอรี่';
$_['text_readmore']  ='อ่านเพิ่มเติม';
?>