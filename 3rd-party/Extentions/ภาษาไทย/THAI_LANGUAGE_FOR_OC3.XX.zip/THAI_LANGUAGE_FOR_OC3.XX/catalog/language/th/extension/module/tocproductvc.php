<?php
// Heading
$_['heading_title'] = 'สินค้าสุดฮอต';
$_['button_view'] =  'รายละเอียดสินค้า';
 
// Text
$_['text_tax']      = 'ยังไม่รวมภาษี:';