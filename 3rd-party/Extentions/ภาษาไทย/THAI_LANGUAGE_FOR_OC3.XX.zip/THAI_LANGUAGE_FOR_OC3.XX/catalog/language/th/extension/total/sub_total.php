<?php
$_['text_sub_total'] = 'ยอดรวมค่าสินค้า';