<?php
// Text
$_['text_viewall']   = 'ดูทั้งหมด';
$_['heading_title']  =  'โปรโมชั่นพิเศษสุด';
 $_['button_view']  =  'รายละเอียดสินค้า';
?>