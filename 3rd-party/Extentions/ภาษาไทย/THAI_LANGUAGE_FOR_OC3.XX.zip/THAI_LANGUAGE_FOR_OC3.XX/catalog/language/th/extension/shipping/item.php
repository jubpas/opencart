<?php
// Text
$_['text_title']       = 'Per Item';
$_['text_description'] = 'ค่าจัดส่งต่อ 1 ชิ้น';