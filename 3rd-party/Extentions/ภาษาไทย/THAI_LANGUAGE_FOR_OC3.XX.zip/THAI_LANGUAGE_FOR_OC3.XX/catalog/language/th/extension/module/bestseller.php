<?php
// Heading
$_['heading_title'] = 'สินค้าขายดี';

// Text
$_['text_tax']      = 'ยังไม่รวมภาษี:';