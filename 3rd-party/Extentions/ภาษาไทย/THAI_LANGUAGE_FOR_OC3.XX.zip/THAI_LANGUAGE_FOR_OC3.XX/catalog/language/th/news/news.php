<?php
// Text
$_['text_news']    = 'ข่าวสารกิจกรรม';
$_['text_heading']     = 'ข่าวสารกิจกรรม';
$_['text_readmore']  ='อ่านเพิ่มเติม';
?>