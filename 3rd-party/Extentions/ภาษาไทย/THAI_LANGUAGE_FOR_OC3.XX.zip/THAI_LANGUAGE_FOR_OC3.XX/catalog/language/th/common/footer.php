<?php
// Text
$_['text_information']  = 'ข้อมูลร้านค้า';
$_['text_service']      = 'บริการลูกค้า';
$_['text_extra']        = 'อื่น ๆ';
$_['text_contact']      = 'ติดต่อเรา';
$_['text_category']      =  'หมวดหมู่สินค้า';
$_['text_article']      =  'บทความ';
$_['text_return']       = 'การคืนสินค้า';
$_['text_sitemap']      = 'แผนผังเว็บไซต์';
$_['text_manufacturer'] = 'แบรนด์';
$_['text_voucher']      = 'ติดตามเราผ่านทางโซเชียล';
$_['text_affiliate']    = 'ตัวแทนขาย';
$_['text_special']      = 'ข้อเสนอพิเสษ';
$_['text_account']      = 'บัญชีผู้ใช้';
$_['text_order']        = 'ประวัติการสั่งซื้อ';
$_['text_wishlist']     = 'รายการโปรด';
$_['text_newsletter']   = 'รับข่าวสารจากทางร้านค้า';
$_['text_powered']      = '<row><div  class="col-sm-6 col-xs-12" >%s &copy; %s</div><div  class="col-sm-6 col-xs-12"><p  class="pull-right "><a href="http://www.templateopencart.net">&nbsp;&nbsp;:&nbsp;&nbsp;TOC สนับสนุนภาษาไทย</a></p>&nbsp;&nbsp;<p class="pull-right " >Powered By <a  href="http://www.opencart.com">OpenCart</a></p></div> </row>'; 