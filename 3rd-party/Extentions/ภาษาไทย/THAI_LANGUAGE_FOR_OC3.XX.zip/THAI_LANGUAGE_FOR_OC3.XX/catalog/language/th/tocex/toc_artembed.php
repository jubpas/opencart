<?php
$_['text_heading']	  = 'บทความล่าสุด';
$_['text_readmore']	  = 'อ่านเพิ่มเติม';