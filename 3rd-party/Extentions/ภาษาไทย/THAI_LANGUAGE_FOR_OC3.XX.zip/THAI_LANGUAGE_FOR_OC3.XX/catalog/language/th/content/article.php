<?php
// Text
$_['text_article']   = 'บทความ';
$_['text_heading']   = 'บทความ';
$_['text_readmore'] ='อ่านเพิ่มเติม';
?>