<?php
// Text
$_['text_captcha'] = 'รหัสป้องกันสแปม';

// Entry
$_['entry_captcha'] = 'ใส่รหัสให้ตรงกับรูปภาพที่ปรากฏ';

// Error
$_['error_captcha'] = 'รหัสที่ใส่ไม่ตรงกับรูปภาพ!';
