<?php
// Heading
$_['heading_title']    = 'แผนผังเว็บไซต์';

// Text
$_['text_special']     = 'ข้อเสนอพิเศษ';
$_['text_account']     = 'บัญชีผู้ใช้';
$_['text_edit']        = 'ข้อมูลผู้ใช้';
$_['text_password']    = 'รหัสผ่าน';
$_['text_address']     = 'ที่อยู่';
$_['text_history']     = 'ประวัติการสั่งซื้อ';
$_['text_download']    = 'ดาวน์โหลด';
$_['text_cart']        = 'ตระกร้าสินค้า';
$_['text_checkout']    = 'ยืนยันการสั่งซื้อ';
$_['text_search']      = 'ค้นหา';
$_['text_information'] = 'ข้อมูลร้านค้า';
$_['text_contact']     = 'ติดต่อเรา';