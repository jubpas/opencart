<?php
// Text
$_['text_title'] = 'เก็บเงินปลายทาง';