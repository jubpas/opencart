<?php
// Heading 
$_['heading_title'] = 'บทความล่าสุด';
$_['text_readmore'] =  'แสดงทั้งหมด';
$_['article_title'] = 'สาระน่ารู้';
$_['project_title'] = 'ผลงานที่ผ่านมา';
// Text
$_['text_reviews']  = 'Based on %s reviews.'; 
?>