<?php
// Text
$_['text_title']       = 'ฟรีค่าจัดส่ง';
$_['text_description'] = 'ฟรีค่าจัดส่ง';