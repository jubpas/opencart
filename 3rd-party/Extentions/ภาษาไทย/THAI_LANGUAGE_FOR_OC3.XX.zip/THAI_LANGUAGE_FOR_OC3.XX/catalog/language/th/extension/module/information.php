<?php
// Heading
$_['heading_title'] = 'ข้อมูลร้านค้า';

// Text
$_['text_contact']  = 'ติดต่อเรา';
$_['text_sitemap']  = 'แผนผังเว็บไซต์';