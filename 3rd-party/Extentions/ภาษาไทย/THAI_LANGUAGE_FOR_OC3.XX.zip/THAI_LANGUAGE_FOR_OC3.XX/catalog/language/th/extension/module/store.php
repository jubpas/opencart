<?php
// Heading
$_['heading_title'] = 'เลือกร้านค้า';

// Text
$_['text_default']  = 'ค่าตั้งต้น';
$_['text_store']    = 'เลือกร้านค้า.';