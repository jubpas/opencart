<?php
// Text
$_['text_contactus']   = 'ติดต่อเรา';
$_['text_address']      =  'ที่ตั้งร้านค้า';
$_['text_about']        = 'เกี่ยวกับเรา';  
?>