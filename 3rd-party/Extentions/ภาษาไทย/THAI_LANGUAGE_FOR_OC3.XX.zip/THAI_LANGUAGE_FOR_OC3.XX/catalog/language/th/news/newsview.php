<?php
// Text
$_['text_related'] =     'ข่าวสารกิจกรรมอื่น ๆ ';
?>