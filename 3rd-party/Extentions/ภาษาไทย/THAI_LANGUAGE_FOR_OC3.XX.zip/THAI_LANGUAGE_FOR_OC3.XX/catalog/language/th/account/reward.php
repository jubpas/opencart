<?php
// Heading
$_['heading_title']      = 'คะแนนสะสมของคุณ';

// Column
$_['column_date_added']  = 'วันที่';
$_['column_description'] = 'รายละเอียด';
$_['column_points']      = 'คะแนน';

// Text
$_['text_account']       = 'บัญชีผู้ใช้';
$_['text_reward']        = 'คะแนนสะสม';
$_['text_total']         = 'คะแนนสะสมทั้งหมดของคุณคือ:';
$_['text_empty']         = 'คุณยังไม่มีคะแนนสะสม!';