<?php
// Heading
$_['heading_title']    = 'ปิดปรับปรุงระบบ';

// Text
$_['text_maintenance'] = 'แจ้งปิดปรับปรุงระบบ';
$_['text_message']     = '<h1 style="text-align:center;">แจ้งการปิดปรับปรุงระบบชั่วคราว <br/>เว็บไซต์จะกลับมาใช้งานได้ในไม่ช้า  ขออภัยมาณ.ที่นี้ค่ะ</h1>';