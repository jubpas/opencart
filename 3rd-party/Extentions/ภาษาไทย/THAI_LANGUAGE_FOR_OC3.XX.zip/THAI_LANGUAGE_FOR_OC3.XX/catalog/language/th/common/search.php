<?php
// Text
$_['text_search'] = 'ค้นหา';