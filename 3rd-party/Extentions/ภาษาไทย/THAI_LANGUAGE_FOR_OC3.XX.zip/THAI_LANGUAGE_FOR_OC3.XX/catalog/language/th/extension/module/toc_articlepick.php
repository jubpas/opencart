<?php
// Heading 
$_['heading_title'] = 'บทความเด่น';
$_['text_readmore'] = 'ทั้งหมด';
 