<?php
// Heading
$_['heading_title'] = 'หมวดหมู่แกลลอรี่';
$_['text_article_pick'] = 'ภาพเด่น';
?>