<?php
// Text
$_['text_items']    = '%s รายการ - %s';
$_['text_empty']    = 'ยังไม่มีสินค้าในตระกร้า!';
$_['text_cart']     = 'ดูสินค้าในตระกร้า';
$_['text_checkout'] = 'สั่งซื้อ';
$_['text_recurring']  = 'การชำระเงิน';