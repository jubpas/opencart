<?php
// Heading
$_['heading_title'] = 'สินค้าแนะนำ';
$_['button_view']       = 'รายละเอียดสินค้า';
// Text
$_['text_tax']      = 'ยังไม่รวมภาษี:';