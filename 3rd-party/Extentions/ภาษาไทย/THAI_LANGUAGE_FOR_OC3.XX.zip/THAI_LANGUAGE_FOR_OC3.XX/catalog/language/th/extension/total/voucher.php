<?php
// Text
$_['text_voucher'] = 'บัตรกำนัล (%s)';