 <?php
// Text
$_['heading_title']	= 'ชำระเงินด้วยระบบ  Paysbuy';
$_['text_title']	= '';
$_['heading_title00'] = 'ได้รับการชำระค่าสินค้าจาก Paysbuy';
$_['heading_title01'] = 'มีปัญหาเรื่องยอดการจ่ายจาก Paysbuy';
$_['heading_title99'] = 'เกิดข้อผิดพลาดจาก Paysbuy';

$_['text_message00'] = 'ขอบคุณสำหรับการชำระค่าสินค่าผ่านทาง Paysbuy';
$_['text_message01'] = 'มีปัญหาเรื่องยอดเงินจาก Paysbuy';
$_['text_message99'] = 'เกิดข้อผิดพลาดจาก Paysbuy';

$_['text_pay_code'] = 'รหัสของ Paysbuy : ';
$_['text_pay_amt'] = 'ยอดเงินที่จ่ายจาก Paysbuy : ';

$_['text_pay_method1'] = 'ชำระเงินด้วยบัญชีของ Paysbuy ';
$_['text_pay_method2'] = 'ชำระด้วยบัตรเครดิต';
$_['text_pay_method3'] = 'ชำระเงินด้วย Paypal';
$_['text_pay_method4'] = 'ชำระเงินด้วย American Express';
$_['text_pay_method5'] = 'ชำระเงินด้วย Online Direct Debit';
$_['text_pay_method6'] = 'ชำระเงินด้วย Counter Service';
$_['text_pay_method'] = 'วิธีการชำระจาก Paysbuy : ';

$_['text_pay_error'] = 'การสั่งสินค้าจะเสร็จสมบูรณ์ กดปุ่ม ทำรายการต่อ แล้วค่อยทำการชำระค่าสินค้า!';
$_['text_pay_comp'] = 'การสั่งสินค้าจะเสร็จสมบูรณ์ กดปุ่ม ทำรายการต่อ เพื่อทำการสั่งซื้อแบบสมบูรณ์!';

?>