<?php
// Heading
$_['heading_title']     = 'บัญชีการดาวน์โหลด';

// Text
$_['text_account']      = 'บัญชี';
$_['text_downloads']    = 'การดาวน์โหลด';
$_['text_empty']        = 'คุณไม่มีรายการสินค้าดาวน์โหลด!';

// Column
$_['column_order_id']   = 'รหัสคำสั่งซื้อ';
$_['column_name']       = 'ชื่อ';
$_['column_size']       = 'ขนาดไฟล์';
$_['column_date_added'] = 'วันที่';