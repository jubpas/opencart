<?php
// Heading
$_['heading_title']    = 'จดหมายข่าวอิเล็กทรอนิค';

// Text
$_['text_account']     = 'บัญชีผู้ใช้';
$_['text_newsletter']  = 'จดหมายข่าว';
$_['text_success']     = 'สถานะเสร็จสมบูรณ์:  ปรับสถานะการรับข่าวสารเรียบร้อยแล้ว!';

// Entry
$_['entry_newsletter'] = 'ต้องการรับข่าวสาร';