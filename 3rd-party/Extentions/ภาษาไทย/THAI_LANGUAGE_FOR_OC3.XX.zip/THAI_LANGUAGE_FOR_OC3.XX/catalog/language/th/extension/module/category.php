<?php
// Heading
$_['heading_title'] = 'หมวดหมู่สินค้า';
$_['text_reset'] = 'ยกเลิกตัวกรองค้นหา';
$_['text_filter'] =  'กรองการค้นหา' ;