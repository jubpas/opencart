<?php
// Text
$_['text_currency'] = 'สกุลเงิน';