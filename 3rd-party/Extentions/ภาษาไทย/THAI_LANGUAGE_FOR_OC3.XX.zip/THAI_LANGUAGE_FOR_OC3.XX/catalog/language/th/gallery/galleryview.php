<?php
// Text
$_['text_related']       = 'แกลลอรี่ที่เกี่ยวข้อง';
?>