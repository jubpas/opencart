<?php
// Text
$_['text_viewall']   = 'ดูทั้งหมด';
$_['heading_title']  =  'ช้อปตามหมวดสินค้า';
$_['button_view'] =  'รายละเอียดสินค้า';
  
?>