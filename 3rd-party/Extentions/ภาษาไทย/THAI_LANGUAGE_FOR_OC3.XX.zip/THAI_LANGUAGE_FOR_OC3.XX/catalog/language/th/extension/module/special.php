<?php
// Heading
$_['heading_title'] = 'สินค้าลดราคา';

// Text
$_['text_tax']      = 'ยังไม่รวมภาษี:';