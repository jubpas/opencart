<?php
// Heading
$_['heading_title']      = 'รายการการทำธุรกรรม';

// Column
$_['column_date_added']  = 'วันที่';
$_['column_description'] = 'รายละเอียด';
$_['column_amount']      = 'จำนวนเงิน (%s)';

// Text
$_['text_account']       = 'บัญชีผู้ใช้';
$_['text_transaction']   = 'การทำธุรกรรม';
$_['text_total']         = 'ยอดเงินคงเหลือในบัญชีคือ:';
$_['text_empty']         = 'คุณยังไม่มีรายการ การทำธุรกรรม!';