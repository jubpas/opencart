<?php
// Text
$_['heading_title']    = 'รายการสินค้าทั้งหมด';
 