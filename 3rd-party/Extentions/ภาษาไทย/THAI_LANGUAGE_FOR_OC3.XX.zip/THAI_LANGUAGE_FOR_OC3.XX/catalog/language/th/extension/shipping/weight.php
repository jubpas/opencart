<?php
// Text
$_['text_title']  = 'ค่าจัดส่งคิดตามน้ำหนัก';
$_['text_weight'] = 'น้ำหนัก:';