<?php
// Text
$_['heading_title']	= 'ชำระเงินด้วยระบบ LinePay';
$_['text_title']	= '<img src="http://ceoneen.com/image/data/payment/line-pay-icon.png">';
$_['text_prefix_desc']	= 'สินค้า  ';
$_['text_checkout']	= 'สรุปรายการคำสั่งซื้อ';
$_['text_testmode']	= 'Warning: The payment gateway is in \'Sandbox Mode\'. Your account will not be charged.';
$_['text_total']	= 'Shipping, Handling, Discounts & Taxes';