<?php
// Heading
$_['heading_title'] = 'ออกจากระบบ';

// Text
$_['text_message']  = '<p>คุณได้ออกจากระบบแล้ว.</p>';
$_['text_account']  = 'บัญชีผู้ใช้';
$_['text_logout']   = 'ออกจากระบบ';