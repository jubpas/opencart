<?php
// Heading
$_['heading_title']      = 'บัญชีผู้ใช้';

// Text
$_['text_account']       = 'บัญชีผู้ใช้';
$_['text_my_account']    = 'บัญชีของฉัน';
$_['text_my_orders']     = 'รายการสั่งซื้อ';
$_['text_my_newsletter'] = 'จดหมายข่าว';
$_['text_edit']          = 'แก้ไขข้อมูลส่วนตัว';
$_['text_password']      = 'เปลี่ยนรหัสผ่าน';
$_['text_address']       = 'แก้ไขที่อยู่';
$_['text_wishlist']      = 'ปรับปรุงรายการโปรด';
$_['text_order']         = 'ดูประวัติการสั่งซื้อ';
$_['text_download']      = 'ดาวน์โหลด';
$_['text_reward']        = 'คะแนนสะสมของคุณ';
$_['text_return']        = 'ติดตามสถานะรายการสินค้าส่งคืน';
$_['text_transaction']   = 'รายการข้อมูล';
$_['text_newsletter']    = 'บอกรับ/ ยกเลิก การรับข่าวสาร';
$_['text_recurring']     = 'การผ่อนชำระ';
$_['text_transactions']  = 'รายการข้อมูล'; 