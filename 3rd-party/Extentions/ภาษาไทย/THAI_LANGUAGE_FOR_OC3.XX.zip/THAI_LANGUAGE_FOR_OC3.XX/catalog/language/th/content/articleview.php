<?php
// Text
$_['text_related']       = 'บทความที่เกี่ยวข้อง';
?>