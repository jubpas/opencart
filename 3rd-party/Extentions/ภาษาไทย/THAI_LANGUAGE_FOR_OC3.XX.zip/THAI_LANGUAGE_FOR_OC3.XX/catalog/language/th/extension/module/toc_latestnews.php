<?php
// Heading 
$_['heading_title'] = '  ข่าวสารกิจกรรม ล่าสุด';
$_['text_readmore'] =  'อ่านเพิ่มเติม';
 
// Text
$_['text_reviews']  = 'Based on %s reviews.'; 
?>