<?php
// Heading
$_['heading_title'] = 'หมวดหมู่บทความ';
$_['text_article_pick'] = 'บทความเด่น';
?>