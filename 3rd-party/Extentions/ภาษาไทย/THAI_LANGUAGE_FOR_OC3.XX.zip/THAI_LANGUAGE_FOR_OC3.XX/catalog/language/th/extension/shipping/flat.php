<?php
// Text
$_['text_title']       = '';
$_['text_description'] = 'ค่าจัดส่งค่อ 1 ออเดอร์';