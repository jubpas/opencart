<?php
// Heading 
$_['heading_title'] = 'สินค้าจัดโปรโมชั่น';
$_['text_timeleft'] = 'เหลือเวลาอีก';
$_['button_view'] =  'รายละเอียดสินค้า';
 
?>